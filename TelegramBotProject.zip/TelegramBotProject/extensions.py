import json
import requests
from config import exchanges

class APIException(Exception):
    pass


class Convertor:
    @staticmethod
    def get_price(base, quote, amount):
        try:
            base_key = exchanges[base.lower()]
        except KeyError:
            raise APIException(f'Валюта {base} не поддерживается')

        try:
            quote_key = exchanges[quote.lower()]
        except KeyError:
            raise APIException(f'Валюта {quote} не поддерживается')

        if base_key == quote_key:
            raise APIException(f'Нельзя конвертировать валюту {base} в саму себя')

        try:
            amount = float(amount)
        except ValueError:
            raise APIException(f'Не удалось обработать количество {amount}!')

        url = f"https://api.apilayer.com/exchangerates_data/latest?symbols={quote_key}&base={base_key}"
        payload = {}
        headers = {
            "apikey": "qh2YKNMcyHPBcWS9eIb0oGPvjW8yZd86"
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        status_code = response.status_code
        result = response.text
        resp = json.loads(response.content)
        new_price = resp['rates'][quote_key] * float(amount)
        new_price = round(new_price, 2)
        message = f"Цена {amount} {base} в {quote} : {new_price}"
        return message
