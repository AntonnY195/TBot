exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}

TOKEN = '5746676796:AAG7Nl4uhemoNZfCBlFaN_zYjDooxaP-9O0'